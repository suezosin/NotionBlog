---
name: Deployment error （部署错误）
about: 在安装部署NotionNext时需要什么帮助吗
title: ''
labels: deployment
assignees: tangly1024
---


<!--
  !!! 重要 !!!
  请遵守这个模板的格式填写，否则你的Issue将被关闭
-->

**描述遇到的问题**
简单说明你遇到的问题，相关的日志、错误信息

**相应配置**
相关的配置，例如notion_page_id；你的网站地址

**截图**
相关的页面，应该用结果

**环境**

- 操作系统: [例如. iOS, Android, macOS, windows]
- 浏览器 [例如. chrome, safari, firefox]
- 版本 [e.g. 22]
